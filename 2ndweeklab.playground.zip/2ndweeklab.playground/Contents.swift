import UIKit
protocol ccode {
    func Ccode()
}
// super class # 1
class Programming : ccode {
    func Ccode() {
        print("yahoo")
    }
    
    
    var language = ""
    var keyword = ""
    var app = ""
    public var device = ""
    func description () {
        print("language : \(language), keyword : \(keyword), app : \(app),device : \(device)")
    }
}






// sub class #1
class Myprogramming : Programming{
    func coding(){
        print("x,y,z")
    }
}
var computer = Myprogramming()
computer.language = "swift"
computer.keyword = "var"
computer.app = "xcode"
computer.device = "ios"
computer.description()











// sub class #2
class xcode : Programming {
        
var keywords : [String] = ["var","let","class","struct","protocol"]
    
}







// sub class #3
class Programmers : Programming {
    enum names : Int{
        case reema = 1
        case remarema = 2
        case reemaahmad = 3
    }
}
var student = Programmers.names(rawValue: 1).self






//sub class #4
class developers : Programming{
    
    struct DevelopersSalary{
        var Daily : Float = 200.9
        var weekly: Int = 1000
        var Monthly : Int = 20000
        var Yearly : Int = 50000
        init(Daily : Float , weekly : Int , Monthly : Int , yearly : Int) {
            self.Daily = Daily
            self.weekly = weekly
            self.Monthly = Monthly
            self.Yearly = yearly
            
        }
        
        
    }
}





// sub class #5
class device : Programming {
    var mymacbook = "laptop"
    func MacBook() {
        print("my \(mymacbook)")
    }
}




// sub class #6
class developersAge : Programming {
        var age: [String : Int] = ["reema":20, "hadeel":24 ,"mayar":27]
}
print(developersAge())




// sub class #7
class laptops : Programming {
    var version : Int = 14
    var name : String = "macbook"
    var capacity : Int = 200
    func Laptops(){
        print("version : \(version), name : \(name), capacity : \(capacity)")
    }
}







// super class #2
protocol educarion {
    func Education()
}
class applications : educarion{
    func Education() {
        print("learning")
    }
    
    var books = "programming"
    var chapters = "one"
    var title = "introduction"
    fileprivate var author = "reema"
    func about () {
        print("books : \(books), chapters : \(chapters), title : \(title),author : \(author)")
    }
}



// sub class #1
class chapterOne : applications {
    var chapone = "swift basics"
    var pages = 8
}



//sub class #2
class chaptertwo : applications {
    var tools : [Int] = [1,2,3,4,5,6,7,8]
}





//sub class #3
class chapterThree : applications {
    var exercises : [String : Int] = ["exercise":1 , "assignment":2]
}
print(exercise)



// sub class #4
class chapterFour : applications {
    enum topics {
        case oop
        case ifstatement
    }
}
var four = chapterFour.ifstatement


//sub class #5
class chapterFive : applications{
    func writeme(){
        print("chapter five")
    }
}
writeme()



// sub class #6
class chapterSix : applications {
    var codes = "coding"
    var time = 24
    var pages = 60
}
print(code)
print(time)
print(pages)





// sub class #7
class chapterSeven : applications {
    
    func resources (){
        print("resources")
    }
}






// super class #3
class bootcamp {
        var about = "swift"
        var time = "2 months"
        var workdays = 5
    }
print("about \(about) , time \(time) , workdays \(workdays)")

 



//sub class #1
class locationnn : bootcamp {
    enum place {
        case riyadh
        case pnu
        case earth
    }
}
var there = locationnn.place





// sub class #2

